<?php

return [
    App\Providers\AppServiceProvider::class,
    Idev\EasyAdmin\EasyAdminServiceProvider::class,
];
