<script>
    function setShowPreview(id) {
        var urlPreview = "<?php echo e(route($uri_key.'.show', 'myid')); ?>"
        urlPreview = urlPreview.replace("myid", id)
        $(".content-preview").html("Processing...")

        $("#section-list-<?php echo e($uri_key); ?>").hide()
        $("#section-preview-<?php echo e($uri_key); ?>").fadeIn('slow')
        $(".text-subtitle").text("Detail <?php echo e($title); ?>")

        $(".close-preview").click(function() {
            $("#section-preview-<?php echo e($uri_key); ?>").hide()
            $("#section-list-<?php echo e($uri_key); ?>").fadeIn('slow')
            $(".text-subtitle").text("List <?php echo e($title); ?>")
        });
        $.ajax({
            url: urlPreview,
            type: "GET",
            success: function (response) {
                $(".content-preview").html(response)
            }
        });
    }
</script><?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/buttons/show.blade.php ENDPATH**/ ?>