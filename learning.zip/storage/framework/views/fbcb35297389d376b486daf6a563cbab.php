<?php
$prefix_repeatable = (isset($repeatable))? true : false;
$select_id = (isset($filter['name']))?$filter['name']:'id_'.$key;
$select_name = (isset($filter['name']))?$filter['name']:'name_'.$key;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($filter['class']))?$filter['class']:'form-group'); ?>">
    <small><?php echo e((isset($filter['label']))?$filter['label']:'Label '.$key); ?></small>
    <select 
        id="<?php echo e($preffix_method); ?><?php echo e($select_id); ?>" 
        name="<?php echo e($select_name); ?>" 
        class="form-control <?php if($prefix_repeatable): ?> filter-repeatable <?php endif; ?>">
        <?php $__currentLoopData = $filter['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($opt['value']); ?>" <?php if(isset($filter['selected_value']) && $opt['value'] == $filter['selected_value']): ?> selected <?php endif; ?>><?php echo e($opt['text']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php if(request('from_ajax') && request('from_ajax') == true): ?>
<div class="push-script">
<?php else: ?>
<?php $__env->startPush('scripts'); ?>
<?php endif; ?>
<script>
$('#<?php echo e($select_id); ?>').on('change', function() {
    updateFilter()        
})
</script>
<?php if(request('from_ajax') && request('from_ajax') == true): ?>
<div class="push-script">
<?php else: ?>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/filters/select.blade.php ENDPATH**/ ?>