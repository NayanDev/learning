<?php $__env->startSection("content"); ?>
<?php $__env->startPush('mtitle'); ?>
<?php echo e($title); ?>

<?php $__env->stopPush(); ?>
<div class="pc-container">
  <div class="pc-content">

    <div class="page-header">
      <div class="page-block">
        <div class="row align-items-center">
          <div class="col-md-12">
            My Account
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-4 col-md-4 col-12">
        <div class="card mb-4">
          <div class="card-body p-3">
            <form id="form-maccount" action="<?php echo e(url('update-profile')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="row">
                <?php $method = "create"; ?>
                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo $__env->make('easyadmin::backend.idev.fields.'.$field['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <hr>
              <button type="button" id="btn-for-form-maccount" class="btn btn-outline-secondary" onclick="softSubmit('form-maccount','list')">
                    Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("easyadmin::backend.parent", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/myaccount.blade.php ENDPATH**/ ?>