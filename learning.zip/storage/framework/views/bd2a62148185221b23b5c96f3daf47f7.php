<?php
$prefix_repeatable = (isset($repeatable))? true : false;
$select_id = (isset($field['name']))?$field['name']:'id_'.$key;
$select_name = (isset($field['name']))?$field['name']:'name_'.$key;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?>

        <?php if(isset($field['required']) && $field['required']): ?>
        <small class="text-danger">*</small>
        <?php endif; ?>
    </label>
    <select 
        id="<?php echo e($preffix_method); ?><?php echo e($select_id); ?>" 
        name="<?php echo e($select_name); ?>" 
        class="form-control idev-form support-live-select2 <?php if($prefix_repeatable): ?> field-repeatable <?php endif; ?>">
        <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($opt['value']); ?>" 
        <?php if($opt['value'] == $field['value'] || $opt['value'] == request($select_name)): ?> selected <?php endif; ?>
        ><?php echo e($opt['text']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php if(isset($field['filter'])): ?>
<?php $__env->startPush('scripts'); ?>
<script>
    var currentUrl = "<?php echo e(url()->current()); ?>"

$('#<?php echo e($select_id); ?>').on('change', function() {
    if (currentUrl.includes("?")) {
        currentUrl += "&<?php echo e($select_name); ?>="+$(this).val()
    }else{
        currentUrl += "?<?php echo e($select_name); ?>="+$(this).val()
    }
    window.location.replace(currentUrl);
})
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/select2.blade.php ENDPATH**/ ?>