<?php
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <?php if(array_key_exists('options', $field)): ?>
    <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($opt['value'] == $field['value']): ?>
        <div class="form-control"> <span id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>"><?php echo e($opt['text']); ?></span> </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="form-control"> <span id="text_<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>"><?php echo e((isset($field['value']))?$field['value']:'-'); ?></span> </div>
    <?php endif; ?>
    <input 
        type="hidden" 
        id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>" 
        name="<?php echo e((isset($field['name']))?$field['name']:'name_'.$key); ?>" 
        value="<?php echo e((isset($field['value']))?$field['value']:''); ?>">
</div>
<?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/onlyview.blade.php ENDPATH**/ ?>