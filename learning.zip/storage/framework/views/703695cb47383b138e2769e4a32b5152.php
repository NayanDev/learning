<?php $__env->startPush('mtitle'); ?>
<?php echo e($title); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection("contentfrontend"); ?>
<div class="auth-main">
    <div class="auth-wrapper v3">
        <div class="auth-form">
            <div class="card my-5">
                <div class="card-body">

                    <a href="https://Sampharindo.id" class="d-flex justify-content-center">
                        <img src="<?php echo e(asset('easyadmin/idev/img/logo-idev.png')); ?>" class="img-responsive" style="width:300px;">
                    </a>
                    <div class="row">
                        <div class="d-flex justify-content-center">
                            <div class="auth-header">
                                <h2 class="my-3"><b>Login to your account</b></h2>
                            </div>
                        </div>
                    </div>

                    <form id="form-login" action="<?php echo e(url('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" name="email" placeholder="Email address / Username" />
                            <label for="floatingInput">Email address / Username</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" name="password" placeholder="Password" />
                            <label for="floatingInput">Password</label>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="button" class="btn btn-outline-secondary" id="btn-for-form-login" onclick="submitAfterValid('form-login', '-login')">Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Menangani peristiwa tekan tombol Enter pada elemen formulir
    document.getElementById("form-login").addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault(); // Mencegah aksi default formulir (mengirimkan formulir)
            submitAfterValid('form-login', '-login'); // Panggil fungsi yang menangani pengiriman formulir
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("easyadmin::frontend.parent", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\learning\resources\views/frontend/login.blade.php ENDPATH**/ ?>