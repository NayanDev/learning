<?php
$counting = 0;
$arrKey = [];
$da = $detail->toArray();
?>
<?php $__currentLoopData = $da; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(str_contains($key, "btn_") == false): ?>
<?php
$counting++;
$arrKey[] = $key;
?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card">
    <div class='card-body'>
        <div class="row">

            <?php if($counting > 6): ?>
            <?php $max = round($counting/2); ?>
            <div class="col-md-6">
                <?php for($i = 0; $i < $max; $i++): ?> <p>
                    <small><?php echo e(str_replace("_", " ", $arrKey[$i])); ?> </small><br>
                    <?php if($arrKey[$i] == 'view_image'): ?>
                    <img src="<?php echo e($da[$arrKey[$i]]); ?>" class='img-thumbnail img-responsive' width='120px' alt="">
                    <?php else: ?>
                    <b><?php echo e($da[$arrKey[$i]] ?? "-"); ?></b>
                    <?php endif; ?>
                    </p>
                    <?php endfor; ?>
            </div>
            <div class="col-md-6">
                <?php for($j = $max; $j < $counting; $j++): ?> <p>
                    <small><?php echo e(str_replace("_", " ", $arrKey[$j])); ?> </small><br>
                    <?php if($arrKey[$j] == 'view_image'): ?>
                    <img src="<?php echo e($da[$arrKey[$j]]); ?>" class='img-thumbnail img-responsive' width='120px' alt="">
                    <?php else: ?>
                    <b><?php echo e($da[$arrKey[$j]] ?? "-"); ?></b>
                    <?php endif; ?>
                    </p>
                    <?php endfor; ?>
            </div>
            <?php else: ?>
            <div class="col-md-6">
                <?php for($i = 0; $i < $counting; $i++): ?> <p>
                    <small><?php echo e(str_replace("_", " ", $arrKey[$i])); ?> </small><br>
                    <?php if($arrKey[$i] == 'view_image'): ?>
                    <img src="<?php echo e($da[$arrKey[$i]]); ?>" class='img-thumbnail img-responsive' width='120px' alt="">
                    <?php else: ?>
                    <b><?php echo e($da[$arrKey[$i]] ?? "-"); ?></b>
                    <?php endif; ?>
                    </p>
                    <?php endfor; ?>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div><?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/show-default.blade.php ENDPATH**/ ?>