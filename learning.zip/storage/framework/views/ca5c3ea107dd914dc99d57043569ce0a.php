<?php
$prefix_repeatable = (isset($repeatable))? true : false;
$select_id = (isset($field['name']))?$field['name']:'id_'.$key;
$select_name = (isset($field['name']))?$field['name']:'name_'.$key;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?>

        <?php if(isset($field['required']) && $field['required']): ?>
        <small class="text-danger">*</small>
        <?php endif; ?>
    </label>
    <select 
        id="<?php echo e($preffix_method); ?><?php echo e($select_id); ?>" 
        name="<?php echo e($select_name); ?>" 
        class="form-control idev-form support-live-select2 <?php if($prefix_repeatable): ?> field-repeatable <?php endif; ?>"
        <?php if(isset($field['data-target'])): ?> 
        data-target="<?php echo e($field['data-target']); ?>"
        <?php endif; ?>>
        <option value="">-- Select Employee --</option>
        <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($opt['value']); ?>" 
            <?php if($opt['value'] == $field['value'] || $opt['value'] == request($select_name)): ?> selected <?php endif; ?>
            data-email="<?php echo e($opt['email'] ?? ''); ?>"
            data-name="<?php echo e($opt['name'] ?? ''); ?>"
            data-company="<?php echo e($opt['company'] ?? ''); ?>"
            data-divisi="<?php echo e($opt['divisi'] ?? ''); ?>"
            data-unit-kerja="<?php echo e($opt['unit_kerja'] ?? ''); ?>"
            data-status="<?php echo e($opt['status'] ?? ''); ?>"
            data-jk="<?php echo e($opt['jk'] ?? ''); ?>"
            data-telp="<?php echo e($opt['telp'] ?? ''); ?>"
        ><?php echo e($opt['text']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php if(isset($field['filter']) || isset($field['autofill'])): ?>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Filter functionality
    <?php if(isset($field['filter'])): ?>
    var currentUrl = "<?php echo e(url()->current()); ?>";
    $('#<?php echo e($select_id); ?>').on('change', function() {
        if (currentUrl.includes("?")) {
            currentUrl += "&<?php echo e($select_name); ?>="+$(this).val();
        } else {
            currentUrl += "?<?php echo e($select_name); ?>="+$(this).val();
        }
        window.location.replace(currentUrl);
    });
    <?php endif; ?>

    // Autofill functionality
    <?php if(isset($field['autofill']) && $field['autofill']): ?>
    $('#<?php echo e($preffix_method); ?><?php echo e($select_id); ?>').on('change', function() {
        var selectedOption = $(this).find('option:selected');
        
        // Get all data attributes
        var formData = {
            name: selectedOption.data('name'),
            email: selectedOption.data('email'),
            company: selectedOption.data('company'),
            divisi: selectedOption.data('divisi'),
            unit_kerja: selectedOption.data('unit-kerja'),
            status: selectedOption.data('status'),
            jk: selectedOption.data('jk'),
            telp: selectedOption.data('telp')
        };

        // Debug log
        console.log('Selected employee data:', formData);

        // Loop through all fields and set values
        Object.keys(formData).forEach(function(field) {
            var value = formData[field] || '';
            var targetField = $('#<?php echo e($preffix_method); ?>' + field);
            
            if(targetField.length > 0) {
                targetField.val(value);
                
                // Trigger change event for select2 fields
                if(targetField.hasClass('support-live-select2')) {
                    targetField.trigger('change');
                }
            }
        });
    });

    // Initialize select2
    $('.support-live-select2').select2({
        width: '100%',
        allowClear: true,
        placeholder: 'Select an option'
    });

    // Trigger change if option is pre-selected
    if ($('#<?php echo e($preffix_method); ?><?php echo e($select_id); ?>').val()) {
        $('#<?php echo e($preffix_method); ?><?php echo e($select_id); ?>').trigger('change');
    }
    <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\learning\resources\views/backend/idev/fields/user.blade.php ENDPATH**/ ?>