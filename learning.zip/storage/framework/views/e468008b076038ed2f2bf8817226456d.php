<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldPushContent("mtitle"); ?></title>
    <meta charset="utf-8" />
    <meta name="base_url" content="<?php echo e(url('')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="<?php echo e(config('idev.meta_description', 'iDev EasyAdmin is simple package to make your admin project easy to build')); ?>" />
    <meta name="keywords" content="<?php echo e(config('idev.meta_keywords', 'iDev,Berry, Dashboard UI Kit, Bootstrap 5, Admin Template, Admin Dashboard, CRM, CMS, Bootstrap Admin Template')); ?>" />
    <meta name="author" content="CodedThemes" />
	<link rel="icon" href="<?php echo e(config('idev.app_favicon', asset('easyadmin/idev/img/favicon.png'))); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" id="main-font-link" />

    <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/default/fonts/tabler-icons.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/default/fonts/material.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/'.config('idev.theme','default').'/css/style.css')); ?>" id="main-style-link" />
    <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/'.config('idev.theme','default').'/css/style-preset.css')); ?>" id="preset-style-link" />
    <link href="<?php echo e(asset('easyadmin/idev/styles.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldPushContent("festyles"); ?>
</head>

<body>

    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>

    <?php echo $__env->yieldContent("contentfrontend"); ?>

    <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/jquery-3.6.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/theme/default/js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/theme/default/js/pcoded.js')); ?>"></script>
    <script src="<?php echo e(asset('easyadmin/idev/scripts.js')); ?>"></script>
    <?php echo $__env->yieldPushContent("fescripts"); ?>
</body>

</html><?php /**PATH C:\laragon\www\learning\vendor\idevsmg\easyadmin\src/resources/views/frontend/parent.blade.php ENDPATH**/ ?>